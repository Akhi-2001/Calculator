
package calculator;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class UsingInterface implements ActionListener{
    
    String str = null;
    double s1 = 0, s2 = 0, result = 0;
    
    JFrame f;JPanel p1, p2, p3;JTextField t;
    JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, bClear, bPlus, bMinus, bDiv, bMul, bPer, bEqual;
    
    UsingInterface()
    {
        f = new JFrame("Calculator");
        
        p1 = new JPanel();
        p1.setBounds(30, 30, 430, 60);
        p1.setBackground(Color.gray);
        f.add(p1); 
       
        t = new JTextField(15);
        //t.setBounds(40, 40, 400, 30);
        t.setFont(t.getFont().deriveFont(34f));
        p1.add(t);
        
        p2 = new JPanel(new GridLayout(4, 3));
        p2.setBounds(30, 120, 300,300);
        p2.setBackground(Color.gray);
        f.add(p2); 
        
        b1 = new JButton("0");
        b1.setBackground(Color.gray);
        b2 = new JButton("1");
        b2.setBackground(Color.gray);
        b3 = new JButton("2");
        b3.setBackground(Color.gray);
        b4 = new JButton("3");
        b4.setBackground(Color.gray);
        b5 = new JButton("4");
        b5.setBackground(Color.gray);
        b6 = new JButton("5");
        b6.setBackground(Color.gray);
        b7 = new JButton("6");
        b7.setBackground(Color.gray);
        b8 = new JButton("7");
        b8.setBackground(Color.gray);
        b9 = new JButton("8");
        b9.setBackground(Color.gray);
        b10 = new JButton("9");
        b10.setBackground(Color.gray);
        b11 = new JButton(".");
        b11.setBackground(Color.gray);
        b12 = new JButton("00");
        b12.setBackground(Color.gray);
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);
        b8.addActionListener(this);
        b9.addActionListener(this);
        b10.addActionListener(this);
        b11.addActionListener(this);
        b12.addActionListener(this);
        
        
        p2.add(b1);p2.add(b2);p2.add(b3);p2.add(b4);p2.add(b5);
        p2.add(b6);p2.add(b7);p2.add(b8);p2.add(b9);p2.add(b10);
        p2.add(b11);p2.add(b12);
        
        p3 = new JPanel(new GridLayout(7, 1));
        p3.setBounds(360, 120, 98, 300);
        p3.setBackground(Color.gray);
        f.add(p3); 
        
        bClear = new JButton("Clear");
        bClear.setBackground(Color.gray);
        bPlus = new JButton("+");
        bPlus.setBackground(Color.gray);
        bMinus = new JButton("-");
        bMinus.setBackground(Color.gray);
        bDiv = new JButton("/"); 
        bDiv.setBackground(Color.gray);
        bMul = new JButton("*");
        bMul.setBackground(Color.gray);
        bPer = new JButton("%");
        bPer.setBackground(Color.gray);
        bEqual = new JButton("=");
        bEqual.setBackground(Color.gray);
        
        bClear.addActionListener(this);
        bPlus.addActionListener(this);
        bMinus.addActionListener(this);
        bDiv.addActionListener(this);
        bMul.addActionListener(this);
        bPer.addActionListener(this);
        bEqual.addActionListener(this);
        
        p3.add(bClear);p3.add(bPlus);p3.add(bMinus);p3.add(bDiv);p3.add(bMul);p3.add(bPer);p3.add(bEqual);
        
        
        //f.add(t);
        f.setSize(500,500);
        f.setLayout(null);
        f.setResizable(false);
        f.setVisible(true);  
       
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        
        if(e.getSource()==b1){
           t.setText(t.getText()+0);
        }
        if(e.getSource()==b2){
           t.setText(t.getText()+1);
        }
        if(e.getSource()==b3){
           t.setText(t.getText()+2);
        }
        if(e.getSource()==b4){
           t.setText(t.getText()+3);
        }
        if(e.getSource()==b5){
           t.setText(t.getText()+4);
        }
        if(e.getSource()==b6){
           t.setText(t.getText()+5);
        }
        if(e.getSource()==b7){
           t.setText(t.getText()+6);
        }
        if(e.getSource()==b8){
           t.setText(t.getText()+7);
        }
        if(e.getSource()==b9){
           t.setText(t.getText()+8);
        }
        if(e.getSource()==b10){
           t.setText(t.getText()+9);
        }
        if(e.getSource()==b11){
           t.setText(t.getText()+".");
        }
        if(e.getSource()==b12){
           t.setText(t.getText()+0+0);
        }      
        if(e.getSource()==bClear){
            t.setText("");
        }
        
        
        if(e.getSource()==bPlus){
           s1 = Double.parseDouble(t.getText());
           str = "+";
           t.setText("");
        }
        if(e.getSource()==bMinus){
           s1 = Double.parseDouble(t.getText());
           str = "-";
           t.setText("");
        }
        if(e.getSource()==bDiv){
           s1 = Double.parseDouble(t.getText());
           str = "/";
           t.setText("");
        }
        if(e.getSource()==bMul){
           s1 = Double.parseDouble(t.getText());
           str = "*";
           t.setText("");
        }
        if(e.getSource()==bPer){
           s1 = Double.parseDouble(t.getText());
           str = "%";
           t.setText("");
        }
        
        if(e.getSource()==bEqual){
            
            s2 = Double.parseDouble(t.getText());
            if(str.equals("+")){
                result = s1 + s2;
            }else if(str.equals("-")){
                result = s1- s2;
            }else if(str.equals("/")){
                result = s1 / s2;
            }else if(str.equals("*")){
                result = s1 * s2;
            }else if(str.equals("%")){
                result = (s1 * s2) / 100;
            }
            
            t.setText(""+result);
            str = " ";
        }
        
    }
    
    public static void main(String[] args) {
        
        new UsingInterface();
    }
     
}
